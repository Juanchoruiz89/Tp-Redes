// productos.js - Funcionalidades específicas para la página de productos

class ProductosPage {
  constructor() {
    this.productos = [];
    this.productosFiltrados = [];
    this.carrito = new Carrito();
    this.categoriaActual = "todos";
    this.filtroActual = "todos";
    this.ordenActual = "default";
    this.paginaActual = 1;
    this.productosPorPagina = 8;

    this.inicializar();
  }

  async inicializar() {
    await this.cargarProductos();
    this.inicializarEventListeners();
    this.renderizarProductos();
  }

  // Cargar productos desde la API
  async cargarProductos() {
    const loadingElement = document.getElementById("loading-products");

    try {
      // En desarrollo, usar datos mock
      if (
        window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1"
      ) {
        // Simular una pequeña demora para simular carga
        await new Promise((resolve) => setTimeout(resolve, 800));
        this.productos = this.obtenerProductosMock(30);
      } else {
        // En producción, obtener de la API
        const response = await fetch(`${API_BASE_URL}/productos/?limit=50`);
        const data = await response.json();
        this.productos = data.results || data;
      }

      this.productosFiltrados = [...this.productos];

      // Ocultar indicador de carga
      if (loadingElement) {
        loadingElement.style.display = "none";
      }
    } catch (error) {
      console.error("Error al cargar productos:", error);

      // En caso de error, usar datos mock
      this.productos = this.obtenerProductosMock(20);
      this.productosFiltrados = [...this.productos];

      if (loadingElement) {
        loadingElement.innerHTML =
          '<p class="text-danger">Error al cargar productos. Mostrando datos de ejemplo.</p>';
      }
    }
  }

  // Datos de prueba para desarrollo
  obtenerProductosMock(cantidad = 20) {
    const categorias = [
      "Vestidos",
      "Blusas",
      "Pantalones",
      "Faldas",
      "Abrigos",
      "Accesorios",
    ];
    const talles = ["XS", "S", "M", "L", "XL"];
    const productos = [];

    for (let i = 1; i <= cantidad; i++) {
      const categoriaIndex = Math.floor(Math.random() * categorias.length);
      const talleIndex = Math.floor(Math.random() * talles.length);
      const precio = Math.floor(Math.random() * 100) + 19.99;
      const destacado = i <= 8;
      const oferta = i % 5 === 0;
      const precioOferta = oferta ? precio * 0.7 : precio;

      productos.push({
        id: i,
        nombre: `Producto ${i} - ${categorias[categoriaIndex]}`,
        descripcion: `Descripción del producto ${i}. Un producto de alta calidad en la categoría ${categorias[categoriaIndex]}.`,
        precio: precioOferta,
        precioOriginal: oferta ? precio : null,
        categoria: categorias[categoriaIndex],
        talle: talles[talleIndex],
        imagen: `https://images.unsplash.com/photo-15${
          1000 + i
        }?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80`,
        stock: Math.floor(Math.random() * 50) + 5,
        destacado: destacado,
        oferta: oferta,
        fecha_creacion: new Date().toISOString(),
      });
    }

    return productos;
  }

  // Inicializar event listeners
  inicializarEventListeners() {
    // Filtros por categoría
    document.querySelectorAll("[data-categoria]").forEach((button) => {
      button.addEventListener("click", (e) => {
        e.preventDefault();
        this.categoriaActual = e.target.dataset.categoria;
        this.aplicarFiltros();
      });
    });

    // Filtros por tipo
    document.querySelectorAll(".btn-filter").forEach((button) => {
      button.addEventListener("click", (e) => {
        // Remover clase active de todos los botones
        document.querySelectorAll(".btn-filter").forEach((btn) => {
          btn.classList.remove("active");
        });

        // Agregar clase active al botón clickeado
        e.target.classList.add("active");

        this.filtroActual = e.target.dataset.filter;
        this.aplicarFiltros();
      });
    });

    // Ordenar productos
    const sortSelect = document.getElementById("sort-products");
    if (sortSelect) {
      sortSelect.addEventListener("change", (e) => {
        this.ordenActual = e.target.value;
        this.aplicarFiltros();
      });
    }

    // Buscar productos
    const searchInput = document.getElementById("buscar-productos");
    const searchButton = document.getElementById("btn-buscar");

    if (searchInput) {
      // Buscar al escribir (con debounce)
      let timeout;
      searchInput.addEventListener("input", (e) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => {
          this.buscarProductos(e.target.value);
        }, 300);
      });

      // Buscar al hacer click en el botón
      if (searchButton) {
        searchButton.addEventListener("click", () => {
          this.buscarProductos(searchInput.value);
        });
      }

      // Buscar al presionar Enter
      searchInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
          this.buscarProductos(searchInput.value);
        }
      });
    }

    // Botón para restablecer filtros
    const resetButton = document.getElementById("reset-filters");
    if (resetButton) {
      resetButton.addEventListener("click", () => {
        this.resetearFiltros();
      });
    }
  }

  // Aplicar filtros y ordenamiento
  aplicarFiltros() {
    let productosFiltrados = [...this.productos];

    // Filtrar por categoría
    if (this.categoriaActual && this.categoriaActual !== "todos") {
      productosFiltrados = productosFiltrados.filter(
        (producto) =>
          producto.categoria.toLowerCase() ===
          this.categoriaActual.toLowerCase()
      );
    }

    // Filtrar por tipo
    if (this.filtroActual === "destacados") {
      productosFiltrados = productosFiltrados.filter(
        (producto) => producto.destacado
      );
    } else if (this.filtroActual === "ofertas") {
      productosFiltrados = productosFiltrados.filter(
        (producto) => producto.oferta || producto.precioOriginal
      );
    }

    // Ordenar productos
    productosFiltrados = this.ordenarProductos(productosFiltrados);

    this.productosFiltrados = productosFiltrados;
    this.paginaActual = 1;
    this.renderizarProductos();
  }

  // Ordenar productos según el criterio seleccionado
  ordenarProductos(productos) {
    switch (this.ordenActual) {
      case "price-asc":
        return [...productos].sort((a, b) => a.precio - b.precio);
      case "price-desc":
        return [...productos].sort((a, b) => b.precio - a.precio);
      case "name-asc":
        return [...productos].sort((a, b) => a.nombre.localeCompare(b.nombre));
      case "name-desc":
        return [...productos].sort((a, b) => b.nombre.localeCompare(a.nombre));
      default:
        return productos;
    }
  }

  // Buscar productos por término
  buscarProductos(termino) {
    if (!termino.trim()) {
      this.productosFiltrados = [...this.productos];
      this.aplicarFiltros();
      return;
    }

    const terminoLower = termino.toLowerCase();
    this.productosFiltrados = this.productos.filter(
      (producto) =>
        producto.nombre.toLowerCase().includes(terminoLower) ||
        producto.descripcion.toLowerCase().includes(terminoLower) ||
        producto.categoria.toLowerCase().includes(terminoLower)
    );

    this.paginaActual = 1;
    this.renderizarProductos();
  }

  // Restablecer filtros
  resetearFiltros() {
    this.categoriaActual = "todos";
    this.filtroActual = "todos";
    this.ordenActual = "default";

    // Restablecer UI
    document.querySelectorAll(".btn-filter").forEach((btn) => {
      btn.classList.remove("active");
    });
    document.querySelector('[data-filter="todos"]').classList.add("active");

    const sortSelect = document.getElementById("sort-products");
    if (sortSelect) {
      sortSelect.value = "default";
    }

    const searchInput = document.getElementById("buscar-productos");
    if (searchInput) {
      searchInput.value = "";
    }

    this.productosFiltrados = [...this.productos];
    this.renderizarProductos();
  }

  // Renderizar productos en el DOM
  renderizarProductos() {
    const container = document.getElementById("products-container");
    const noProductsElement = document.getElementById("no-products");
    const loadingElement = document.getElementById("loading-products");
    const paginationElement = document.getElementById("pagination-container");

    if (!container) return;

    // Ocultar indicador de carga si está visible
    if (loadingElement && loadingElement.style.display !== "none") {
      loadingElement.style.display = "none";
    }

    // Verificar si hay productos
    if (this.productosFiltrados.length === 0) {
      container.innerHTML = "";

      if (noProductsElement) {
        noProductsElement.style.display = "block";
      }

      if (paginationElement) {
        paginationElement.style.display = "none";
      }

      return;
    }

    // Ocultar mensaje de "no productos"
    if (noProductsElement) {
      noProductsElement.style.display = "none";
    }

    // Calcular productos para la página actual
    const inicio = (this.paginaActual - 1) * this.productosPorPagina;
    const fin = inicio + this.productosPorPagina;
    const productosPagina = this.productosFiltrados.slice(inicio, fin);

    // Renderizar productos
    container.innerHTML = "";
    productosPagina.forEach((producto) => {
      const productoHTML = this.crearCardProducto(producto);
      container.innerHTML += productoHTML;
    });

    // Actualizar paginación
    this.actualizarPaginacion();

    // Agregar event listeners a los botones de los productos
    this.agregarEventListenersProductos();
  }

  // Crear HTML para una card de producto
  crearCardProducto(producto) {
    const esOferta = producto.oferta || producto.precioOriginal;
    const precioOriginal = esOferta ? producto.precioOriginal : null;
    const descuento = esOferta
      ? Math.round((1 - producto.precio / precioOriginal) * 100)
      : 0;

    return `
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="product-card h-100">
                    ${
                      esOferta
                        ? `<div class="badge-oferta">-${descuento}%</div>`
                        : ""
                    }
                    ${
                      producto.destacado
                        ? `<div class="badge-destacado">Destacado</div>`
                        : ""
                    }
                    
                    <div class="product-img">
                        <img src="${
                          producto.imagen || "img/producto-default.jpg"
                        }" 
                             alt="${producto.nombre}" 
                             class="img-fluid">
                    </div>
                    
                    <div class="product-info d-flex flex-column">
                        <span class="product-category">${
                          producto.categoria || "Ropa"
                        }</span>
                        <h3 class="product-title">${producto.nombre}</h3>
                        
                        <div class="product-price">
                            ${
                              esOferta
                                ? `
                                <span class="price-old">$${precioOriginal.toFixed(
                                  2
                                )}</span>
                                <span class="price-new">$${producto.precio.toFixed(
                                  2
                                )}</span>
                            `
                                : `$${producto.precio.toFixed(2)}`
                            }
                        </div>
                        
                        <div class="product-talle mb-2">
                            <small>Talle: <strong>${
                              producto.talle
                            }</strong></small>
                        </div>
                        
                        <div class="product-stock mb-3">
                            <small class="${
                              producto.stock > 0
                                ? "text-success"
                                : "text-danger"
                            }">
                                <i class="fas ${
                                  producto.stock > 0
                                    ? "fa-check-circle"
                                    : "fa-times-circle"
                                }"></i>
                                ${
                                  producto.stock > 0
                                    ? `${producto.stock} disponibles`
                                    : "Agotado"
                                }
                            </small>
                        </div>
                        
                        <div class="product-actions mt-auto">
                            <button class="btn btn-cart btn-agregar-carrito" data-id="${
                              producto.id
                            }" 
                                    ${producto.stock === 0 ? "disabled" : ""}>
                                <i class="fas fa-shopping-cart"></i> 
                                ${producto.stock > 0 ? "Agregar" : "Agotado"}
                            </button>
                            <button class="btn btn-details btn-ver-detalles" data-id="${
                              producto.id
                            }">
                                <i class="fas fa-eye"></i> Ver
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
  }

  // Actualizar paginación
  actualizarPaginacion() {
    const paginationElement = document.getElementById("pagination-container");
    if (!paginationElement) return;

    const totalPaginas = Math.ceil(
      this.productosFiltrados.length / this.productosPorPagina
    );

    if (totalPaginas <= 1) {
      paginationElement.style.display = "none";
      return;
    }

    paginationElement.style.display = "block";

    let paginationHTML = `
            <nav aria-label="Paginación de productos">
                <ul class="pagination justify-content-center">
        `;

    // Botón anterior
    if (this.paginaActual > 1) {
      paginationHTML += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="${
                      this.paginaActual - 1
                    }">Anterior</a>
                </li>
            `;
    } else {
      paginationHTML += `
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1">Anterior</a>
                </li>
            `;
    }

    // Números de página
    const paginasVisibles = 5;
    let inicioPagina = Math.max(
      1,
      this.paginaActual - Math.floor(paginasVisibles / 2)
    );
    let finPagina = Math.min(totalPaginas, inicioPagina + paginasVisibles - 1);

    if (finPagina - inicioPagina + 1 < paginasVisibles) {
      inicioPagina = Math.max(1, finPagina - paginasVisibles + 1);
    }

    for (let i = inicioPagina; i <= finPagina; i++) {
      if (i === this.paginaActual) {
        paginationHTML += `
                    <li class="page-item active">
                        <a class="page-link" href="#" data-page="${i}">${i}</a>
                    </li>
                `;
      } else {
        paginationHTML += `
                    <li class="page-item">
                        <a class="page-link" href="#" data-page="${i}">${i}</a>
                    </li>
                `;
      }
    }

    // Botón siguiente
    if (this.paginaActual < totalPaginas) {
      paginationHTML += `
                <li class="page-item">
                    <a class="page-link" href="#" data-page="${
                      this.paginaActual + 1
                    }">Siguiente</a>
                </li>
            `;
    } else {
      paginationHTML += `
                <li class="page-item disabled">
                    <a class="page-link" href="#" tabindex="-1">Siguiente</a>
                </li>
            `;
    }

    paginationHTML += `
                </ul>
            </nav>
        `;

    paginationElement.innerHTML = paginationHTML;

    // Agregar event listeners a los enlaces de paginación
    this.agregarEventListenersPaginacion();
  }

  // Agregar event listeners a la paginación
  agregarEventListenersPaginacion() {
    document.querySelectorAll(".page-link[data-page]").forEach((link) => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        const pagina = parseInt(e.target.dataset.page);
        if (!isNaN(pagina)) {
          this.paginaActual = pagina;
          this.renderizarProductos();

          // Desplazarse hacia arriba para ver los productos
          window.scrollTo({
            top: document.getElementById("products-container").offsetTop - 100,
            behavior: "smooth",
          });
        }
      });
    });
  }

  // Agregar event listeners a los botones de productos
  agregarEventListenersProductos() {
    // Botones "Agregar al carrito"
    document.querySelectorAll(".btn-agregar-carrito").forEach((button) => {
      button.addEventListener("click", (e) => {
        const productoId = parseInt(
          e.target.closest(".btn-agregar-carrito").dataset.id
        );
        const producto = this.productos.find((p) => p.id === productoId);

        if (producto && producto.stock > 0) {
          this.carrito.agregarProducto(producto);
        } else if (producto && producto.stock === 0) {
          this.carrito.mostrarNotificacion(
            "Este producto está agotado",
            "warning"
          );
        }
      });
    });

    // Botones "Ver detalles"
    document.querySelectorAll(".btn-ver-detalles").forEach((button) => {
      button.addEventListener("click", (e) => {
        const productoId = parseInt(
          e.target.closest(".btn-ver-detalles").dataset.id
        );
        this.verDetallesProducto(productoId);
      });
    });
  }

  // Ver detalles del producto
  verDetallesProducto(productoId) {
    // En una implementación completa, redirigiría a una página de detalles
    // Para este ejemplo, mostramos un modal simple
    const producto = this.productos.find((p) => p.id === productoId);

    if (producto) {
      const modalHTML = `
                <div class="modal fade" id="productoModal" tabindex="-1" aria-labelledby="productoModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="productoModalLabel">${
                                  producto.nombre
                                }</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                            </div>
                            <div class="modal-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <img src="${producto.imagen}" alt="${
        producto.nombre
      }" class="img-fluid rounded">
                                    </div>
                                    <div class="col-md-6">
                                        <h4>$${producto.precio.toFixed(2)}</h4>
                                        <p><strong>Categoría:</strong> ${
                                          producto.categoria
                                        }</p>
                                        <p><strong>Talle:</strong> ${
                                          producto.talle
                                        }</p>
                                        <p><strong>Disponibilidad:</strong> ${
                                          producto.stock > 0
                                            ? "En stock"
                                            : "Agotado"
                                        }</p>
                                        <p>${producto.descripcion}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                <button type="button" class="btn btn-primary" id="agregar-desde-modal" data-id="${
                                  producto.id
                                }" 
                                        ${
                                          producto.stock === 0 ? "disabled" : ""
                                        }>
                                    <i class="fas fa-shopping-cart"></i> Agregar al carrito
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;

      // Agregar modal al DOM si no existe
      let modal = document.getElementById("productoModal");
      if (!modal) {
        document.body.insertAdjacentHTML("beforeend", modalHTML);
        modal = document.getElementById("productoModal");

        // Agregar event listener al botón del modal
        const agregarButton = document.getElementById("agregar-desde-modal");
        if (agregarButton) {
          agregarButton.addEventListener("click", () => {
            if (producto.stock > 0) {
              this.carrito.agregarProducto(producto);

              // Cerrar modal
              const bsModal = bootstrap.Modal.getInstance(modal);
              bsModal.hide();
            }
          });
        }
      }

      // Mostrar modal
      const bsModal = new bootstrap.Modal(modal);
      bsModal.show();
    }
  }
}

// Inicializar la página de productos cuando el DOM esté listo
document.addEventListener("DOMContentLoaded", function () {
  // Verificar si estamos en la página de productos
  if (
    window.location.pathname.includes("productos.html") ||
    document.getElementById("products-container")
  ) {
    const productosPage = new ProductosPage();
  }
});
