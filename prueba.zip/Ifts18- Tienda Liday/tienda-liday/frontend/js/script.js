// Configuración para desarrollo
const IS_DEVELOPMENT =
  window.location.hostname === "localhost" ||
  window.location.hostname === "127.0.0.1";

// Usar datos mock en desarrollo
if (IS_DEVELOPMENT) {
  console.log("🔧 Modo desarrollo activado - Usando datos mock");
}

// script.js - Funcionalidades principales de Tienda Liday

// API Base URL (para desarrollo local)
const API_BASE_URL = "http://localhost:8000/api";
// Para producción, cambiar a la URL del deploy
// const API_BASE_URL = 'https://tu-api-deploy.com/api';

// Clase para manejar el carrito
class Carrito {
  constructor() {
    this.carrito = this.obtenerCarritoStorage();
    this.actualizarContadorCarrito();
    this.inicializarEventListeners();
  }

  // Obtener carrito del localStorage
  obtenerCarritoStorage() {
    const carritoStorage = localStorage.getItem("carritoLiday");
    return carritoStorage
      ? JSON.parse(carritoStorage)
      : { items: [], total: 0, cantidad: 0 };
  }

  // Guardar carrito en localStorage
  guardarCarritoStorage() {
    localStorage.setItem("carritoLiday", JSON.stringify(this.carrito));
  }

  // Actualizar contador del carrito en la interfaz
  actualizarContadorCarrito() {
    const cartCountElement = document.getElementById("cart-count");
    if (cartCountElement) {
      const totalItems = this.carrito.items.reduce(
        (total, item) => total + item.cantidad,
        0
      );
      cartCountElement.textContent = totalItems;
      cartCountElement.style.display = totalItems > 0 ? "flex" : "none";
    }
  }

  // Agregar producto al carrito
  agregarProducto(producto, cantidad = 1) {
    // Verificar si el producto ya está en el carrito
    const itemIndex = this.carrito.items.findIndex(
      (item) => item.id === producto.id
    );

    if (itemIndex > -1) {
      // Si ya existe, aumentar cantidad
      this.carrito.items[itemIndex].cantidad += cantidad;
    } else {
      // Si no existe, agregar nuevo item
      this.carrito.items.push({
        id: producto.id,
        nombre: producto.nombre,
        precio: producto.precio,
        imagen: producto.imagen,
        cantidad: cantidad,
      });
    }

    // Recalcular totales
    this.calcularTotales();

    // Guardar en localStorage y actualizar interfaz
    this.guardarCarritoStorage();
    this.actualizarContadorCarrito();

    // Mostrar notificación
    this.mostrarNotificacion(`${producto.nombre} agregado al carrito`);

    return this.carrito;
  }

  // Eliminar producto del carrito
  eliminarProducto(productoId) {
    this.carrito.items = this.carrito.items.filter(
      (item) => item.id !== productoId
    );
    this.calcularTotales();
    this.guardarCarritoStorage();
    this.actualizarContadorCarrito();

    // Si estamos en la página del carrito, actualizar la vista
    if (window.location.pathname.includes("carrito.html")) {
      this.actualizarVistaCarrito();
    }
  }

  // Actualizar cantidad de un producto
  actualizarCantidad(productoId, nuevaCantidad) {
    const itemIndex = this.carrito.items.findIndex(
      (item) => item.id === productoId
    );

    if (itemIndex > -1) {
      if (nuevaCantidad > 0) {
        this.carrito.items[itemIndex].cantidad = nuevaCantidad;
      } else {
        // Si la cantidad es 0, eliminar el producto
        this.eliminarProducto(productoId);
        return;
      }

      this.calcularTotales();
      this.guardarCarritoStorage();
      this.actualizarContadorCarrito();

      // Si estamos en la página del carrito, actualizar la vista
      if (window.location.pathname.includes("carrito.html")) {
        this.actualizarVistaCarrito();
      }
    }
  }

  // Calcular totales del carrito
  calcularTotales() {
    this.carrito.cantidad = this.carrito.items.reduce(
      (total, item) => total + item.cantidad,
      0
    );
    this.carrito.total = this.carrito.items.reduce(
      (total, item) => total + item.precio * item.cantidad,
      0
    );
  }

  // Obtener carrito completo
  obtenerCarrito() {
    return this.carrito;
  }

  // Vaciar carrito
  vaciarCarrito() {
    this.carrito = { items: [], total: 0, cantidad: 0 };
    this.guardarCarritoStorage();
    this.actualizarContadorCarrito();

    // Si estamos en la página del carrito, actualizar la vista
    if (window.location.pathname.includes("carrito.html")) {
      this.actualizarVistaCarrito();
    }

    this.mostrarNotificacion("Carrito vaciado");
  }

  // Mostrar notificación
  mostrarNotificacion(mensaje, tipo = "success") {
    // Eliminar notificación anterior si existe
    const notificacionAnterior = document.querySelector(".custom-notification");
    if (notificacionAnterior) {
      notificacionAnterior.remove();
    }

    // Crear nueva notificación
    const notificacion = document.createElement("div");
    notificacion.className = `custom-notification alert alert-${tipo}`;
    notificacion.textContent = mensaje;
    notificacion.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            animation: slideIn 0.3s ease;
        `;

    document.body.appendChild(notificacion);

    // Eliminar después de 3 segundos
    setTimeout(() => {
      notificacion.style.animation = "slideOut 0.3s ease";
      setTimeout(() => notificacion.remove(), 300);
    }, 3000);
  }

  // Actualizar vista del carrito (para carrito.html)
  actualizarVistaCarrito() {
    const carritoContainer = document.getElementById("carrito-items");
    const carritoTotal = document.getElementById("carrito-total");
    const carritoVacio = document.getElementById("carrito-vacio");
    const carritoLleno = document.getElementById("carrito-lleno");

    if (!carritoContainer) return;

    if (this.carrito.items.length === 0) {
      // Mostrar mensaje de carrito vacío
      if (carritoVacio) carritoVacio.style.display = "block";
      if (carritoLleno) carritoLleno.style.display = "none";
    } else {
      // Mostrar items del carrito
      if (carritoVacio) carritoVacio.style.display = "none";
      if (carritoLleno) carritoLleno.style.display = "block";

      carritoContainer.innerHTML = "";

      this.carrito.items.forEach((item) => {
        const subtotal = item.precio * item.cantidad;

        const itemHTML = `
                    <div class="carrito-item row align-items-center mb-4 py-3 border-bottom">
                        <div class="col-md-2">
                            <img src="${
                              item.imagen || "img/producto-default.jpg"
                            }" 
                                 alt="${item.nombre}" 
                                 class="img-fluid rounded">
                        </div>
                        <div class="col-md-4">
                            <h5>${item.nombre}</h5>
                            <p class="text-muted mb-0">Código: ${item.id}</p>
                        </div>
                        <div class="col-md-2">
                            <p class="mb-0 fw-bold">$${item.precio.toFixed(
                              2
                            )}</p>
                        </div>
                        <div class="col-md-2">
                            <div class="input-group cantidad-input">
                                <button class="btn btn-outline-secondary btn-cantidad-restar" type="button" data-id="${
                                  item.id
                                }">-</button>
                                <input type="number" class="form-control text-center" value="${
                                  item.cantidad
                                }" min="1" data-id="${item.id}">
                                <button class="btn btn-outline-secondary btn-cantidad-sumar" type="button" data-id="${
                                  item.id
                                }">+</button>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <p class="mb-0 fw-bold subtotal">$${subtotal.toFixed(
                              2
                            )}</p>
                            <button class="btn btn-link btn-eliminar text-danger p-0 mt-1" data-id="${
                              item.id
                            }">
                                <i class="fas fa-trash"></i> Eliminar
                            </button>
                        </div>
                    </div>
                `;

        carritoContainer.innerHTML += itemHTML;
      });

      // Actualizar total
      if (carritoTotal) {
        carritoTotal.textContent = `$${this.carrito.total.toFixed(2)}`;
      }

      // Agregar event listeners a los botones de cantidad y eliminar
      this.agregarEventListenersCarrito();
    }
  }

  // Agregar event listeners a los elementos del carrito
  agregarEventListenersCarrito() {
    // Botones para restar cantidad
    document.querySelectorAll(".btn-cantidad-restar").forEach((button) => {
      button.addEventListener("click", (e) => {
        const productoId = parseInt(e.target.dataset.id);
        const item = this.carrito.items.find((item) => item.id === productoId);

        if (item && item.cantidad > 1) {
          this.actualizarCantidad(productoId, item.cantidad - 1);
        }
      });
    });

    // Botones para sumar cantidad
    document.querySelectorAll(".btn-cantidad-sumar").forEach((button) => {
      button.addEventListener("click", (e) => {
        const productoId = parseInt(e.target.dataset.id);
        const item = this.carrito.items.find((item) => item.id === productoId);

        if (item) {
          this.actualizarCantidad(productoId, item.cantidad + 1);
        }
      });
    });

    // Inputs de cantidad
    document.querySelectorAll(".cantidad-input input").forEach((input) => {
      input.addEventListener("change", (e) => {
        const productoId = parseInt(e.target.dataset.id);
        const nuevaCantidad = parseInt(e.target.value);

        if (nuevaCantidad > 0) {
          this.actualizarCantidad(productoId, nuevaCantidad);
        } else {
          e.target.value = 1;
        }
      });
    });

    // Botones de eliminar
    document.querySelectorAll(".btn-eliminar").forEach((button) => {
      button.addEventListener("click", (e) => {
        const productoId = parseInt(
          e.target.closest(".btn-eliminar").dataset.id
        );
        this.eliminarProducto(productoId);
      });
    });
  }

  // Inicializar event listeners globales
  inicializarEventListeners() {
    // Botón para vaciar carrito
    const btnVaciarCarrito = document.getElementById("vaciar-carrito");
    if (btnVaciarCarrito) {
      btnVaciarCarrito.addEventListener("click", () => {
        if (confirm("¿Estás seguro de que quieres vaciar el carrito?")) {
          this.vaciarCarrito();
        }
      });
    }

    // Botón para proceder al pago
    const btnPagar = document.getElementById("proceder-pago");
    if (btnPagar) {
      btnPagar.addEventListener("click", () => {
        if (this.carrito.items.length === 0) {
          alert(
            "Tu carrito está vacío. Agrega productos antes de proceder al pago."
          );
        } else {
          alert("Redirigiendo al proceso de pago...");
          // En una implementación real, aquí redirigirías a la pasarela de pago
        }
      });
    }
  }
}

// Clase para manejar productos
class Productos {
  constructor() {
    this.carrito = new Carrito();
  }

  // Obtener productos de la API
  async obtenerProductos(limit = 8) {
    try {
      // En desarrollo, usar datos de prueba si la API no está disponible
      if (
        window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1"
      ) {
        // Simular datos de prueba para desarrollo
        return this.obtenerProductosMock(limit);
      }

      const response = await fetch(`${API_BASE_URL}/productos/?limit=${limit}`);

      if (!response.ok) {
        throw new Error(`Error HTTP: ${response.status}`);
      }

      const data = await response.json();
      return data.results || data;
    } catch (error) {
      console.error("Error al obtener productos:", error);
      // En caso de error, usar datos de prueba
      return this.obtenerProductosMock(limit);
    }
  }

  // Obtener productos destacados
  async obtenerProductosDestacados(limit = 4) {
    try {
      // En desarrollo, usar datos de prueba
      if (
        window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1"
      ) {
        // Simular datos de prueba para desarrollo
        return this.obtenerProductosMock(limit).filter((p) => p.destacado);
      }

      const response = await fetch(
        `${API_BASE_URL}/productos/destacados/?limit=${limit}`
      );

      if (!response.ok) {
        throw new Error(`Error HTTP: ${response.status}`);
      }

      const data = await response.json();
      return data.results || data;
    } catch (error) {
      console.error("Error al obtener productos destacados:", error);
      // En caso de error, usar datos de prueba
      return this.obtenerProductosMock(limit).filter((p) => p.destacado);
    }
  }

  // Datos de prueba para desarrollo
  obtenerProductosMock(limit = 8) {
    const productosMock = [
      {
        id: 1,
        nombre: "Vestido Floral Veraniego",
        descripcion:
          "Vestido ligero con estampado floral, perfecto para días cálidos.",
        precio: 49.99,
        categoria: "Vestidos",
        talle: "M",
        imagen:
          "https://images.unsplash.com/photo-1566174053879-31528523f8ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        stock: 15,
        destacado: true,
      },
      {
        id: 2,
        nombre: "Blusa de Seda Elegante",
        descripcion:
          "Blusa de seda natural con cuello barco, ideal para ocasiones especiales.",
        precio: 39.99,
        categoria: "Blusas",
        talle: "S",
        imagen:
          "https://images.unsplash.com/photo-1586790170083-2f9ceadc732d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        stock: 8,
        destacado: true,
      },
      {
        id: 3,
        nombre: "Jeans Skinny Azul Oscuro",
        descripcion: "Jeans ajustados en tela elástica para mayor comodidad.",
        precio: 59.99,
        categoria: "Pantalones",
        talle: "L",
        imagen:
          "https://images.unsplash.com/photo-1542272604-787c3835535d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        stock: 20,
        destacado: true,
      },
      {
        id: 4,
        nombre: "Falda Plisada Negra",
        descripcion:
          "Falda elegante con pliegues finos, perfecta para el trabajo.",
        precio: 44.99,
        categoria: "Faldas",
        talle: "M",
        imagen:
          "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        stock: 12,
        destacado: false,
      },
      {
        id: 5,
        nombre: "Chaqueta de Cuero Sintético",
        descripcion: "Chaqueta moderna en cuero sintético de alta calidad.",
        precio: 79.99,
        categoria: "Abrigos",
        talle: "L",
        imagen:
          "https://images.unsplash.com/photo-1551028719-00167b16eac5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        stock: 7,
        destacado: true,
      },
      {
        id: 6,
        nombre: "Top de Encaje Blanco",
        descripcion:
          "Top delicado con detalles de encaje, ideal para combinar.",
        precio: 29.99,
        categoria: "Blusas",
        talle: "XS",
        imagen:
          "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        stock: 18,
        destacado: false,
      },
      {
        id: 7,
        nombre: "Vestido de Noche Largo",
        descripcion:
          "Vestido elegante para eventos formales, con detalles en lentejuelas.",
        precio: 129.99,
        categoria: "Vestidos",
        talle: "M",
        imagen:
          "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        stock: 5,
        destacado: false,
      },
      {
        id: 8,
        nombre: "Pantalón de Vestir Cremallera",
        descripcion:
          "Pantalón elegante con detalle de cremallera en la pierna.",
        precio: 54.99,
        categoria: "Pantalones",
        talle: "S",
        imagen:
          "https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
        stock: 14,
        destacado: false,
      },
    ];

    return productosMock.slice(0, limit);
  }

  // Renderizar productos en el DOM
  async renderizarProductosDestacados() {
    const container = document.getElementById("featured-products-container");

    if (!container) return;

    try {
      const productos = await this.obtenerProductosDestacados(4);

      if (productos.length === 0) {
        container.innerHTML =
          '<p class="text-center">No hay productos disponibles en este momento.</p>';
        return;
      }

      container.innerHTML = "";

      productos.forEach((producto) => {
        const productoHTML = this.crearCardProducto(producto);
        container.innerHTML += productoHTML;
      });

      // Agregar event listeners a los botones de "Agregar al carrito"
      this.agregarEventListenersProductos();
    } catch (error) {
      console.error("Error al renderizar productos:", error);
      container.innerHTML =
        '<p class="text-center text-danger">Error al cargar los productos. Por favor, intenta nuevamente.</p>';
    }
  }

  // Crear HTML para una card de producto
  crearCardProducto(producto) {
    return `
            <div class="col-md-3 col-sm-6 mb-4">
                <div class="product-card h-100">
                    <div class="product-img">
                        <img src="${
                          producto.imagen || "img/producto-default.jpg"
                        }" 
                             alt="${producto.nombre}" 
                             class="img-fluid">
                    </div>
                    <div class="product-info d-flex flex-column">
                        <span class="product-category">${
                          producto.categoria || "Ropa"
                        }</span>
                        <h3 class="product-title">${producto.nombre}</h3>
                        <div class="product-price">$${producto.precio.toFixed(
                          2
                        )}</div>
                        <div class="product-actions mt-auto">
                            <button class="btn btn-cart btn-agregar-carrito" data-id="${
                              producto.id
                            }">
                                <i class="fas fa-shopping-cart"></i> Agregar
                            </button>
                            <button class="btn btn-details btn-ver-detalles" data-id="${
                              producto.id
                            }">
                                <i class="fas fa-eye"></i> Ver
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
  }

  // Agregar event listeners a los botones de productos
  agregarEventListenersProductos() {
    // Botones "Agregar al carrito"
    document.querySelectorAll(".btn-agregar-carrito").forEach((button) => {
      button.addEventListener("click", (e) => {
        const productoId = parseInt(
          e.target.closest(".btn-agregar-carrito").dataset.id
        );
        this.agregarProductoAlCarrito(productoId);
      });
    });

    // Botones "Ver detalles"
    document.querySelectorAll(".btn-ver-detalles").forEach((button) => {
      button.addEventListener("click", (e) => {
        const productoId = parseInt(
          e.target.closest(".btn-ver-detalles").dataset.id
        );
        this.verDetallesProducto(productoId);
      });
    });
  }

  // Agregar producto al carrito
  async agregarProductoAlCarrito(productoId) {
    try {
      // Obtener información del producto
      let producto;

      if (
        window.location.hostname === "localhost" ||
        window.location.hostname === "127.0.0.1"
      ) {
        // En desarrollo, usar datos mock
        const productos = this.obtenerProductosMock();
        producto = productos.find((p) => p.id === productoId);
      } else {
        // En producción, obtener de la API
        const response = await fetch(
          `${API_BASE_URL}/productos/${productoId}/`
        );
        producto = await response.json();
      }

      if (producto) {
        this.carrito.agregarProducto(producto);
      }
    } catch (error) {
      console.error("Error al agregar producto al carrito:", error);
      this.carrito.mostrarNotificacion(
        "Error al agregar el producto",
        "danger"
      );
    }
  }

  // Ver detalles del producto
  async verDetallesProducto(productoId) {
    // En una implementación completa, redirigiría a una página de detalles
    alert(`Mostrar detalles del producto ${productoId}`);
    // window.location.href = `producto.html?id=${productoId}`;
  }
}

// Clase para manejar formularios
class Formularios {
  constructor() {
    this.inicializarFormularios();
  }

  inicializarFormularios() {
    // Formulario de contacto
    const formularioContacto = document.getElementById("formulario-contacto");
    if (formularioContacto) {
      formularioContacto.addEventListener("submit", (e) =>
        this.manejarEnvioContacto(e)
      );
    }

    // Formulario de newsletter
    const formularioNewsletter = document.getElementById("newsletter-form");
    if (formularioNewsletter) {
      formularioNewsletter.addEventListener("submit", (e) =>
        this.manejarNewsletter(e)
      );
    }
  }

  // Manejar envío del formulario de contacto
  manejarEnvioContacto(e) {
    e.preventDefault();

    const formulario = e.target;
    const datos = new FormData(formulario);

    // Validación básica
    const nombre = datos.get("nombre");
    const email = datos.get("email");
    const mensaje = datos.get("mensaje");

    if (!this.validarFormularioContacto(nombre, email, mensaje)) {
      return;
    }

    // Aquí normalmente enviaríamos los datos a Formspree
    // Para este ejemplo, simulamos el envío

    // Mostrar mensaje de éxito
    this.mostrarMensajeFormulario(
      formulario,
      "¡Mensaje enviado con éxito! Te responderemos pronto.",
      "success"
    );

    // Resetear formulario
    formulario.reset();

    // En producción, usaríamos Formspree:
    // fetch('https://formspree.io/f/your-form-id', {
    //     method: 'POST',
    //     body: datos,
    //     headers: {
    //         'Accept': 'application/json'
    //     }
    // })
    // .then(response => {
    //     if (response.ok) {
    //         this.mostrarMensajeFormulario(formulario, '¡Mensaje enviado con éxito! Te responderemos pronto.', 'success');
    //         formulario.reset();
    //     } else {
    //         throw new Error('Error en el envío');
    //     }
    // })
    // .catch(error => {
    //     this.mostrarMensajeFormulario(formulario, 'Hubo un error al enviar el mensaje. Por favor, intenta nuevamente.', 'danger');
    // });
  }

  // Validar formulario de contacto
  validarFormularioContacto(nombre, email, mensaje) {
    let valido = true;

    // Limpiar mensajes de error previos
    document.querySelectorAll(".error-message").forEach((el) => el.remove());
    document
      .querySelectorAll(".is-invalid")
      .forEach((el) => el.classList.remove("is-invalid"));

    // Validar nombre
    if (!nombre || nombre.trim().length < 2) {
      this.mostrarError("nombre", "El nombre debe tener al menos 2 caracteres");
      valido = false;
    }

    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      this.mostrarError("email", "Por favor, ingresa un email válido");
      valido = false;
    }

    // Validar mensaje
    if (!mensaje || mensaje.trim().length < 10) {
      this.mostrarError(
        "mensaje",
        "El mensaje debe tener al menos 10 caracteres"
      );
      valido = false;
    }

    return valido;
  }

  // Mostrar error en un campo del formulario
  mostrarError(campoId, mensaje) {
    const campo = document.getElementById(campoId);
    if (campo) {
      campo.classList.add("is-invalid");

      const errorDiv = document.createElement("div");
      errorDiv.className = "error-message invalid-feedback";
      errorDiv.textContent = mensaje;

      campo.parentNode.appendChild(errorDiv);
    }
  }

  // Mostrar mensaje de éxito/error en el formulario
  mostrarMensajeFormulario(formulario, mensaje, tipo) {
    // Eliminar mensaje anterior si existe
    const mensajeAnterior = formulario.querySelector(".form-message");
    if (mensajeAnterior) {
      mensajeAnterior.remove();
    }

    // Crear nuevo mensaje
    const mensajeDiv = document.createElement("div");
    mensajeDiv.className = `form-message alert alert-${tipo} mt-3`;
    mensajeDiv.textContent = mensaje;

    formulario.appendChild(mensajeDiv);

    // Desaparecer después de 5 segundos
    setTimeout(() => {
      mensajeDiv.remove();
    }, 5000);
  }

  // Manejar suscripción al newsletter
  manejarNewsletter(e) {
    e.preventDefault();

    const formulario = e.target;
    const emailInput = formulario.querySelector('input[type="email"]');
    const email = emailInput.value;

    // Validar email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
      emailInput.classList.add("is-invalid");

      const errorDiv = document.createElement("div");
      errorDiv.className = "error-message invalid-feedback";
      errorDiv.textContent = "Por favor, ingresa un email válido";

      emailInput.parentNode.appendChild(errorDiv);
      return;
    }

    // Aquí normalmente enviaríamos los datos a un servicio de email
    // Para este ejemplo, simulamos el envío

    // Mostrar mensaje de éxito
    alert("¡Gracias por suscribirte a nuestro newsletter!");

    // Resetear formulario
    formulario.reset();
  }
}

// Inicializar la aplicación cuando el DOM esté listo
document.addEventListener("DOMContentLoaded", function () {
  // Inicializar clases principales
  const productos = new Productos();
  const formularios = new Formularios();

  // Renderizar productos destacados si estamos en la página principal
  if (document.getElementById("featured-products-container")) {
    productos.renderizarProductosDestacados();
  }

  // Inicializar vista del carrito si estamos en la página del carrito
  if (window.location.pathname.includes("carrito.html")) {
    productos.carrito.actualizarVistaCarrito();
  }

  // Agregar estilos para las notificaciones
  const estiloNotificaciones = document.createElement("style");
  estiloNotificaciones.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
        
        .custom-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            animation: slideIn 0.3s ease;
        }
    `;
  document.head.appendChild(estiloNotificaciones);

  // Navegación suave para enlaces internos
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      const href = this.getAttribute("href");

      if (href === "#") return;

      e.preventDefault();

      const targetElement = document.querySelector(href);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80,
          behavior: "smooth",
        });

        // Cerrar menú móvil si está abierto
        const navbarCollapse = document.querySelector(".navbar-collapse.show");
        if (navbarCollapse) {
          const bsCollapse = new bootstrap.Collapse(navbarCollapse);
          bsCollapse.hide();
        }
      }
    });
  });

  // Mejorar accesibilidad del teclado
  document.addEventListener("keydown", function (e) {
    // Atajo para ir al carrito (Alt + C)
    if (e.altKey && e.key === "c") {
      const carritoLink = document.querySelector('a[href="carrito.html"]');
      if (carritoLink) {
        carritoLink.focus();
        carritoLink.click();
      }
    }

    // Atajo para buscar (Alt + S)
    if (e.altKey && e.key === "s") {
      const searchInput = document.querySelector(".search-box input");
      if (searchInput) {
        searchInput.focus();
      }
    }
  });
});
