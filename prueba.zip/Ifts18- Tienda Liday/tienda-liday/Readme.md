# Tienda Liday - E-commerce Project

# Tienda Liday - E-commerce de Indumentaria Femenina

![Tienda Liday](https://images.unsplash.com/photo-1490481651871-ab68de25d43d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1950&q=80)

## Descripción del Proyecto

Tienda Liday es un sitio web de e-commerce completo especializado en indumentaria femenina. El proyecto implementa todas las funcionalidades necesarias para una tienda online moderna, incluyendo catálogo de productos, carrito de compras, formulario de contacto y diseño responsivo.

## Características Principales

### Frontend

- **Diseño responsivo** que se adapta a móviles, tablets y desktop
- **Interfaz moderna y atractiva** con Bootstrap 5 y CSS personalizado
- **Navegación intuitiva** con menú semántico y accesible
- **Optimización SEO** con metaetiquetas apropiadas y estructura semántica
- **Accesibilidad** mejorada con ARIA labels y navegación por teclado

### Funcionalidades

- **Catálogo de productos** dinámico consumiendo datos de API REST
- **Carrito de compras** con persistencia en localStorage
- **Filtrado y búsqueda** de productos por categoría, precio y nombre
- **Formulario de contacto** funcional integrado con Formspree
- **Página de producto** con detalles completos y opciones de compra
- **Sistema de reseñas** de clientes con diseño en grid

### Backend (Opcional)

- **API REST** desarrollada con Django REST Framework
- **Modelos de datos** para productos, categorías y carritos
- **Autenticación** de usuarios y sesiones
- **Panel de administración** Django para gestión de productos

## Estructura del Proyecto

## Tecnologías Utilizadas

### Frontend

- **HTML5** con estructura semántica
- **CSS3** con Flexbox, Grid y Media Queries
- **Bootstrap 5** para componentes y diseño responsivo
- **JavaScript Vanilla** para interactividad
- **Font Awesome** para iconos
- **Google Fonts** para tipografía

### Backend (Opcional)

- **Python 3.8+**
- **Django 4.0+**
- **Django REST Framework**
- **SQLite/PostgreSQL** (base de datos)

### Herramientas de Desarrollo

- **Git** para control de versiones
- **Netlify** para despliegue del frontend
- **Formspree** para manejo de formularios

## Instalación y Configuración

### Opción 1: Solo Frontend (Recomendado para Netlify)

1. Clonar el repositorio:
   ```bash
   git clone https://github.com/tuusuario/tienda-liday.git
   cd tienda-liday
   ```
